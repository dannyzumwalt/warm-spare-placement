import googlemaps
import argparse
from datetime import datetime
from config import GOOGLE_MAPS_API_KEY
from origins import origins
import destinations  # Import the destinations module

def calculate_drive_time(start_location, destination, traffic_model=None):
    """Calculates the driving time from the start location to a single destination."""
    # Initialize Google Maps client
    gmaps = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)

    # Build request parameters
    params = {
        "origins": [start_location],
        "destinations": [destination],
        "mode": "driving",
    }

    # Add traffic-aware parameters if a traffic model is specified
    if traffic_model:
        params["departure_time"] = datetime.now()
        params["traffic_model"] = traffic_model

    # Generate driving time for a single origin-destination pair
    distance_matrix = gmaps.distance_matrix(**params)

    # Extract the duration from the response
    rows = distance_matrix.get("rows", [])
    if rows:
        elements = rows[0].get("elements", [])
        if elements and elements[0].get("status") == "OK":
            # Prefer duration_in_traffic when available
            if "duration_in_traffic" in elements[0]:
                return elements[0]["duration_in_traffic"]["text"]
            return elements[0]["duration"]["text"]
    return "Not Available"

def format_duration(duration):
    """Converts a duration string to the format 'H:M'."""
    if duration == "Not Available":
        return "N/A"
    parts = duration.split()
    hours, minutes = 0, 0
    for i in range(len(parts)):
        if "hour" in parts[i]:
            hours = int(parts[i - 1])
        elif "min" in parts[i]:
            minutes = int(parts[i - 1])
    return f"{hours}:{minutes:02}"

def print_drive_time_csv(origin_key, dest_key, duration):
    """Prints the driving time for a single origin-destination pair in CSV format."""
    formatted_duration = format_duration(duration)
    print(f"{origin_key},{dest_key},{formatted_duration}")

def print_drive_time_readable(origin_key, origin_address, dest_key, dest_address, duration):
    """Prints the driving time for a single origin-destination pair in readable format."""
    print(f"Driving time from {origin_key} ({origin_address}) to {dest_key} ({dest_address}): {duration}")

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Calculate driving times from a starting location to a list of destinations.")
    parser.add_argument("--origin", required=True, help="Key of the starting location from origins.py")
    parser.add_argument("--dest", required=True, help="Key of the destination dictionary in destinations.py")
    parser.add_argument("--csv", action="store_true", help="Output results in CSV format")
    parser.add_argument("--traffic", choices=["now", "pessimistic", "optimistic"], default=None,
                        help="Traffic model: 'now' (best_guess with live traffic), 'pessimistic', or 'optimistic'. "
                             "Omit for static historical average (default, lower cost).")
    args = parser.parse_args()

    # Map --traffic flag to Google API traffic_model parameter
    traffic_model_map = {
        "now": "best_guess",
        "pessimistic": "pessimistic",
        "optimistic": "optimistic",
    }
    traffic_model = traffic_model_map.get(args.traffic)

    # Get the starting location
    origin_key = args.origin
    if origin_key not in origins:
        print(f"Error: Invalid origin key '{origin_key}'. Available keys are: {', '.join(origins.keys())}")
        exit(1)
    start_location = origins[origin_key]

    # Get the destination dictionary
    dest_key = args.dest
    if not hasattr(destinations, dest_key):
        print(f"Error: Invalid destination key '{dest_key}'. Available keys are: {', '.join([key for key in dir(destinations) if not key.startswith('__')])}")
        exit(1)
    destination_dict = getattr(destinations, dest_key)

    # Calculate and display driving times for each destination
    if start_location and destination_dict:
        for dest_key, dest_address in destination_dict.items():
            duration = calculate_drive_time(start_location, dest_address, traffic_model=traffic_model)

            if args.csv:
                print_drive_time_csv(origin_key, dest_key, duration)
            else:
                print_drive_time_readable(origin_key, start_location, dest_key, dest_address, duration)
    else:
        print("Start location or destinations list is empty.")

