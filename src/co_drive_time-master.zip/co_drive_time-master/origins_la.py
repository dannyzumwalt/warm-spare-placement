# origins.py
origins = {
    "RVSDCA01": "3580 Orange St., Riverside, CA 92501",
    "ANHMCA01": "217 N Lemon, Anaheim, CA 92805",
    "IRVNCA11": "2350 Main Street, Irving, CA 92614"
    # Add more key-value pairs as needed
}

