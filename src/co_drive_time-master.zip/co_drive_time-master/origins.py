# origins.py
origins = {
    "RVSDCA01": "3580 Orange St., Riverside, CA 92501",
    "ANHMCA01": "217 N Lemon, Anaheim, CA 92805",
    "IRVNCA11": "2350 Main Street, Irving, CA 92614",
    "LSANCA03": "420 S Grand Ave, Los Angeles, CA",
    "SHOKCA02": "14800 Ventura Blvd, Sherman Oaks, CA",
    "OKCYOKCE": "121 DEAN A MCGEE AVE, Oklahoma City, OK",
    "OKCYOKWI": "NW 3701 23RD ST, Oklahoma City, OK",
    "TULSOKNA": "8321 E 41ST ST, Tulsa, OK",
    "TULSOKTB": "510 S ELGIN AVE, Tulsa, OK",
    "ATLNGANW": "3450 RIVERWOOD PKWY SE, Atlanta, GA",
    "PANLGAMW": "5225 Minola Dr, Lithonia, GA",
    "ATLNGAEP": "3065 MAIN ST, Atlanta, GA",
# Add more key-value pairs as needed
}
