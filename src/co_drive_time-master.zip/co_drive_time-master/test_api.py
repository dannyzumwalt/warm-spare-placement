import googlemaps

# Replace 'YOUR_API_KEY' with your actual Google Maps API key
gmaps = googlemaps.Client(key="AIzaSyAnhV4B-x2sfTGnJeVwZ6EFaYgrME2P48I")

# Example: Geocode an address
address = "1600 Amphitheatre Parkway, Mountain View, CA"
geocode_result = gmaps.geocode(address)

print("Geocode Result:")
print(geocode_result)

# Example: Get driving directions
directions_result = gmaps.directions("New York, NY", "Los Angeles, CA")

print("\nDirections Result:")
print(directions_result)
