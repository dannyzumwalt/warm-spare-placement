# CO Drive Time Calculator

The Drive Time Calculator is a Python-based tool that calculates driving times from a specified starting location to a list of destinations using the Google Maps API. The tool supports both human-readable and CSV output formats, making it versatile for different use cases like reporting or integration with spreadsheets.

---

## **Features**
1. **Dynamic Origin Selection**:
   - Specify the starting location dynamically at runtime using a key from `origins.py`.

2. **Dynamic Destination Selection**:
   - Specify the destination list dynamically at runtime using a key from `destinations.py`.

3. **Accurate Drive Time Calculation**:
   - Uses the Google Maps API to compute driving times for each origin-destination pair.

4. **Multi-Format Output**:
   - **Human-Readable Format**:
     - Example: `Driving time from CO1 (1600 Amphitheatre Parkway, Mountain View, CA) to DST1 (123 Main St, Oklahoma City, OK): 1 hour, 32 minutes`
   - **CSV Format**:
     - Example: `CO1,DST1,1:32`

5. **Error Handling**:
   - Handles invalid origin or destination keys gracefully by displaying available options.

---

## **File Structure**
```plaintext
.
+-- main.py           # Main script to run the tool
+-- origins.py        # Dictionary of origin keys and addresses
+-- destinations.py   # Dictionary of destination keys and addresses
+-- config.py         # Contains the Google Maps API key
```

---

## **How to Use**

### **1. Prerequisites**
- Python 3.6 or above.
- Install the required dependencies from `requirements.txt`:
  ```bash
  pip install -r requirements.txt
  ```

- A valid Google Maps API key in `config.py` (Free to setup for moderate lookup volumes):
  ```python
  GOOGLE_MAPS_API_KEY = "your-google-maps-api-key"
  ```

### **2. Setup Origins and Destinations**
- Define your origins in `origins.py`:
  ```python
  origins = {
      "CO1": "1600 Amphitheatre Parkway, Mountain View, CA",
      "CO2": "1 Infinite Loop, Cupertino, CA"
  }
  ```

- Define your destinations in `destinations.py` (DST1 can be a CLLI8):
  ```python
  okc = {
      "DST1": "123 Main St, Oklahoma City, OK",
      "DST2": "456 Elm St, Oklahoma City, OK"
  }
  ```

### **3. Run the Tool**

#### **Human-Readable Output**
Example:
```bash
python3 main.py --origin CO1 --dest okc
```

Output:
```
Driving time from CO1 (1600 Amphitheatre Parkway, Mountain View, CA) to DST1 (123 Main St, Oklahoma City, OK): 22 hours, 30 minutes
Driving time from CO1 (1600 Amphitheatre Parkway, Mountain View, CA) to DST2 (456 Elm St, Oklahoma City, OK): 22 hours, 45 minutes
```

#### **CSV Output**
Example:
```bash
python3 main.py --origin CO1 --dest okc --csv
```

Output:
```
CO1,DST1,22:30
CO1,DST2,22:45
```

---

## **Current Limitations**
- **Single Origin**: The tool only supports calculations from one origin at a time.
- **API Rate Limits**: Ensure your Google Maps API key has sufficient quota for multiple requests.
- **No Offline Mode**: Requires an active internet connection to fetch results from Google Maps API.
- **No CLLI8 Address Lookup**: Requires feeding and building the addresses for each origin and destination. 
